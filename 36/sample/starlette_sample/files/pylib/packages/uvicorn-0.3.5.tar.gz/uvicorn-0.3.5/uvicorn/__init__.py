from uvicorn.main import main, run

__version__ = "0.3.5"
__all__ = ["main", "run"]
